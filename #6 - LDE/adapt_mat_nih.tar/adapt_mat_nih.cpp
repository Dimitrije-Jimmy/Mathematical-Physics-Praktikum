/*
  Preverjanje natancnosti integratorja NDE 1. reda na primeru integriranja
  matematicneg nihala
  
    y'' + sin(y) = 0        H = 1/2 (y'^2 + 1- cos(y))

  Diferencialno enacbo integriramo prepisano NDE 1. reda z uvedbo nove
  spremenljivke:
  
    dx/dt  =  p
                                            ==  x = F(t, x)
    dp/dt = -sin(y)

  Prevajanje: g++ traj.cpp -o traj -O2
  
  Avtor: Martin Horvat, januar 2008
*/

#include <iostream>
#include <cmath>

//#define EMBEDDED

#if defined(EMBEDDED)
#include "integrator2.h"
#else
#include "integrator1.h"
#endif

template <class T>  T sqr(const T & x) {return x*x;}

/* 
  Desna stran 1. NDE 
*/
double energy(double *x){
  return 1 - cos(x[0]) + 0.5*x[1]*x[1];
}

class Derivative {

  public:
  
  void operator()(const double &t, double *x, double *dxdt){
    dxdt[0] = x[1];
    dxdt[1] = -sin(x[0]);
    
  }
};

unsigned long long int start, end;

int main(int argc, char **argv ){

  if (argc != 3){
    std::cerr 
      << "usage: ./traj <x0:x0'> <dt:T> > <energy at steps>\n"
      << "note:\n"
      << "  x0:x0' -- intial point\n"
      << "  dt:T -- time step and whole interval\n";
       
    exit(EXIT_FAILURE);  
  }

  
  double t = 0, dt, T, H,
         *x = new double [2];
  
  sscanf(argv[1], "%lf:%lf", x, x + 1);
  sscanf(argv[2], "%lf:%lf", &dt, &T);
 
  // lahko izberemo razlicne metode in pristop (vlozene ali nevlozene)
  #if defined(EMBEDDED)
  //RKM4<double,double,Derivative> doint(2);  // Marsonova metoda
  Hairer8<double,double,Derivative> doint(2);  // Hairer (p=8)
  #else
  RK4<double,double,Derivative> doint(2);     // Standardna RK4
  //Hairer8<double,double,Derivative> doint(2); // Hairer (p=8)
  //Hairer10<double,double,Derivative> doint(2); // // Hairer (p=10)
  #endif

  H = energy(x);
  std::cout << t << '\t' << x[0] << '\t' << x[1] << '\t' << 0 << std::endl;
  
  while (t <= T) {
    
    doint.step(dt, t, x);
    
    std::cout << t << '\t' << x[0] << '\t' << x[1] << '\t'
              << energy(x) - H << std::endl;
    t += dt;
  }
  
  delete [] x;
  
  return EXIT_SUCCESS;
}
