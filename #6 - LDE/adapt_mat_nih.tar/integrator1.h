#if !defined(__integrator_h)
#define __integrator_h

/* 
  Integrator of 1. order ODE defined as 
  
    dx/dt = F(t, x)     x in T^d
  
  using an adaptive step in a combination with some explicit method of 
  some order.
  
  Author: Martin Horvat, jan 2008
*/

/* 
  General solver class:
    T  - numerical type for time
    F  - numerical tyep for states
    Derivative  - derivative in ODE (right side of the equation)
    Method  - explicit method of integration with given order
*/


template <class T, class F, class Method>
class TODEsolver {

  int dim;    // dimension of phase space

  
  Method *method;  // pointer to a method
  
  F *s1, *s2;     // states needed in the steping
  
  public:
    
  TODEsolver(int dim) : dim(dim) {  
    method = new Method(dim);
    s1 = new F [dim];
    s2 = new F [dim];  
  }


  ~TODEsolver (){
    delete method;
    delete [] s1;
    delete [] s2;
  }
  
  /*
    Integrator of the ODE dx/dt = F(x). Making a controled step over the 
    length dt with suggested integration step h

    input:
      eps -- relative precision on an interval of output assuming that 
             the error is gaussian distributed around zero
      dt -- time step
      h -- suggested integration step
      t -- current time at which input state is given
      state -- position of the ODE at time t

    output:  
      h -- last integration step
      t -- new time, t+dt
      state -- poistion of the ODE at t+dt
      
    return:
      number of steps done to integrate between [t,t+dt]
  */

  int step(const T &eps, const T &dt, T & h, T & t, F *state, 
           bool normalize = true);
};

#define PERIOD_OF_CHECKING  5
#define PERIOD_OF_NOTCHECKING 100

#define DEBUG
#define TINY 1e-15
#define SUPERTINY 1e-20

template <class T, class F, class Method> 
int TODEsolver <T, F, Method>::step(const T &eps, const T &dt,  
                                    T & h, T & t, F *state, bool normalize) {

  int i, checked = 0, not_checked = 0, 
      a = int(1) << method->order, steps = 0;
  
  bool check = true;
  
  T err, h_out = h, t_end = t + dt;
  
  if (h <= 0) 
    h_out = h = dt/10; 
  else  {
    h_out = h;
    if (t + h > t_end) h = t_end - t;
  }   
 
  do {
    memcpy(s1, state, dim*sizeof(F));
    method -> step(h, t, s1);
    
    if (check) {
      
      memcpy(s2, state, dim*sizeof(F));
      method -> step(0.5*h, t, s2, method -> k[0]); 
      method -> step(0.5*h, t + 0.5*h, s2);

      err = 0;
      if (normalize)
        for (i = 0; i < dim; ++i)
          err = std::max(err, std::abs(s1[i] - s2[i])/
          std::max(1.0, std::max(std::abs(s1[i]), std::abs(s2[i]))));     
      else
        for (i = 0; i < dim; ++i)
          err = std::max(err, std::abs(s1[i] - s2[i]));

      err *= a/(a-1.0);
      
      #if defined(DEBUG)   
      std::cerr << t << '\t' << h << '\t' << err << '\t' << checked << '\n';
      #endif
      
      if (err > eps) {
        h_out = (h *= 0.7*exp(log(eps/err)/(method->order + 1)));
        checked = 0;
      } else {
        t += h;
        for (i = 0; i < dim; ++i) state[i] = (s2[i]*a - s1[i])/(a - 1);
        
        if (std::abs(t - t_end) < TINY) break;
         
        // is the step is to small but larger then zero      
        if (SUPERTINY < err && 10*err < eps) {
          h_out =(h *= 0.7*exp(log(eps/err)/(method->order + 1)));
          checked = 0;
        } else if (++checked > PERIOD_OF_CHECKING) {
          check = false;
          not_checked = 0;
        }
        
        if (t + h > t_end) h = t_end - t; 
      } 
      
    } else {
      #if defined(DEBUG) 
      std::cerr << t << '\n';
      #endif 

      t += h;
      memcpy(state, s1, dim*sizeof(F));

      if (std::abs(t - t_end) < TINY) break;
      
      if (++not_checked > PERIOD_OF_NOTCHECKING) {
        check = true;
        checked = 0;
      }
      
      if (t + h > t_end) h = t_end - t;
    }
               
    ++steps;    
  } while (true);

  h = h_out;
  return steps;
}		        
#undef TINY
#undef SUPERTINY
#undef PERIOD_OF_CHECKING
#undef PERIOD_OF_NOTCHECKING

/*
   RK4 method class
*/

template <class T, class F, class Derivative>
class RK4 {

  int dim;
  
  public:
    
  F **k, *state_;
   
  static int order;
   
  RK4 (int dim):dim(dim){
    k = new F* [4];
    for (int i = 0; i < 4; ++i) k[i] = new F [dim];
    state_ = new F [dim];
  }
  
  ~RK4(){
    for (int i = 0; i < 4; ++i) delete [] k[i];
    delete [] state_;
    delete [] k;
  }
     
  void step(const T &h, const T &t, F *state, F *k0 = 0){

    int i; 

    if (k0 == 0) 
      Derivative()(t, state, k[0]);
    else if (k0 != k[0])
      memcpy(k[0], k0, sizeof(F)*dim);
    
    for (i = 0; i < dim; ++i) 
      state_[i] = state[i] + 0.5*h*k[0][i];

    Derivative()(t + 0.5*h, state_, k[1]);   

    for (i = 0; i < dim; ++i) 
      state_[i] = state[i] + 0.5*h*k[1][i];

    Derivative()(t + 0.5*h, state_, k[2]);
      
    for (i = 0; i < dim; ++i) 
      state_[i] = state[i] + h*k[2][i];
    
    Derivative()(t + h, state_, k[3]);
    
    for (i = 0; i < dim; ++i)
      state[i] += h*(k[0][i] + k[3][i] + 2.0*(k[1][i] + k[2][i]))/6.0;
  }
};

template <class T, class F, class Derivative>
int RK4<T,F,Derivative>::order = 4;

/*
 Hairer (p=8)
*/
template <class T, class F, class Derivative>
class Hairer8 {

  int dim;
  
  T **a, *b, *c;

  public:

  F **k, *state_;

  static int order;
    
  Hairer8 (int dim) : dim(dim) {
    int i, j;
        
    k = new F* [13];    
    for (i = 0; i < 13; ++i) 
      k[i] = new F [dim];
    
    state_ = new F [dim];
    
    a = new T* [12];
 
    for (i = 0; i < 12; ++i) {
      a[i] = new T [i+1];
      for (j = 0; j <= i; ++j) a[i][j] = 0.0;
    }
 
    // Original Prince-Dormand 8 (7), DOPRI 8 in Hairer I
    a[ 0][ 0] =  1.0/18.0;
    a[ 1][ 0] =  1.0/48.0;
    a[ 1][ 1] =  1.0/16.0;
    a[ 2][ 0] =  1.0/32.0;
    a[ 2][ 2] =  3.0/32.0;
    a[ 3][ 0] =  5.0/16.0;
    a[ 3][ 2] = -75.0/64.0;
    a[ 3][ 3] =  75.0/64.0;
    a[ 4][ 0] =  3.0/80.0;
    a[ 4][ 3] =  3.0/16.0;
    a[ 4][ 4] =  3.0/20.0;
    a[ 5][ 0] =  29443841.0/614563906.0;
    a[ 5][ 3] =  77736538.0/692538347.0;
    a[ 5][ 4] = -28693883.0/1125000000.0;
    a[ 5][ 5] =  23124283.0/1800000000.0;
    a[ 6][ 0] =  16016141.0/946692911.0;
    a[ 6][ 3] =  61564180.0/158732637.0;
    a[ 6][ 4] =  22789713.0/633445777.0;
    a[ 6][ 5] =  545815736.0/2771057229.0;
    a[ 6][ 6] = -180193667.0/1043307555.0;
    a[ 7][ 0] =  39632708.0/573591083.0;
    a[ 7][ 3] = -433636366.0/683701615.0;
    a[ 7][ 4] = -421739975.0/2616292301.0;
    a[ 7][ 5] =  100302831.0/723423059.0;
    a[ 7][ 6] =  790204164.0/839813087.0;
    a[ 7][ 7] =  800635310.0/3783071287.0;
    a[ 8][ 0] =  246121993.0/1340847787.0;
    a[ 8][ 3] = -37695042795.0/15268766246.0;
    a[ 8][ 4] = -309121744.0/1061227803.0;
    a[ 8][ 5] = -12992083.0/490766935.0;
    a[ 8][ 6] =  6005943493.0/2108947869.0;
    a[ 8][ 7] =  393006217.0/1396673457.0;
    a[ 8][ 8] =  123872331.0/1001029789.0;
    a[ 9][ 0] = -1028468189.0/846180014.0;
    a[ 9][ 3] =  8478235783.0/508512852.0;
    a[ 9][ 4] =  1311729495.0/1432422823.0;
    a[ 9][ 5] = -10304129995.0/1701304382.0;
    a[ 9][ 6] = -48777925059.0/3047939560.0;
    a[ 9][ 7] =  15336726248.0/1032824649.0;
    a[ 9][ 8] = -45442868181.0/3398467696.0;
    a[ 9][ 9] =  3065993473.0/597172653.0;
    a[10][ 0] =  185892177.0/718116043.0;
    a[10][ 3] = -3185094517.0/667107341.0;
    a[10][ 4] = -477755414.0/1098053517.0;
    a[10][ 5] = -703635378.0/230739211.0;
    a[10][ 6] =  5731566787.0/1027545527.0;
    a[10][ 7] =  5232866602.0/850066563.0;
    a[10][ 8] = -4093664535.0/808688257.0;
    a[10][ 9] =  3962137247.0/1805957418.0;
    a[10][10] =  65686358.0/487910083.0;
    a[11][ 0] =  403863854.0/491063109.0;
    a[11][ 3] = -5068492393.0/434740067.0;
    a[11][ 4] = -411421997.0/543043805.0;
    a[11][ 5] =  652783627.0/914296604.0;
    a[11][ 6] =  11173962825.0/925320556.0;
    a[11][ 7] = -13158990841.0/6184727034.0;
    a[11][ 8] =  3936647629.0/1978049680.0;
    a[11][ 9] = -160528059.0/685178525.0;
    a[11][10] =  248638103.0/1413531060.0;
   
    b = new T [13]; 
    memset(b,0, sizeof(T)*13);
    b[ 0] =  13451932.0/455176623.0;
    b[ 5] = -808719846.0/976000145.0;
    b[ 6] =  1757004468.0/5645159321.0;
    b[ 7] =  656045339.0/265891186.0;
    b[ 8] = -3867574721.0/1518517206.0;
    b[ 9] =  465885868.0/322736535.0;
    b[10] =  53011238.0/667516719.0;
    b[11] =  2.0/45.0;

    c = new T [12];
    c[ 0] =  1.0/18.0;
    c[ 1] =  1.0/12.0;
    c[ 2] =  1.0/8.0;
    c[ 3] =  5.0/16.0;
    c[ 4] =  3.0/8.0;
    c[ 5] =  59.0/400.0;
    c[ 6] =  93.0/200.0;
    c[ 7] =  5490023248.0/9719169821.0;
    c[ 8] =  13.0/20.0;
    c[ 9] =  1201146811.0/1299019798.0;
    c[10] =  1.0;
    c[11] =  1.0;
  
  }
  
  ~Hairer8(){
    int i;

    delete [] b;
    delete [] c;

    for (i = 0; i < 12; i++) delete [] a[i];
    delete [] a;

    delete [] state_;    
    
    for (i = 0; i < 13; i++) delete [] k[i];
    delete [] k;

  }
  
  void step(const T &h, const T &t, F *state, F *k0 = 0){

    int i, j, l;
    
    F tmp;
    
    if (k0 == 0) 
      Derivative()(t, state, k[0]);
    else if (k0 != k[0])
      memcpy(k[0], k0 ,sizeof(F)*dim);
    
    for (i = 0; i < 12; ++i) {
      
      for (l = 0; l < dim; ++l) {
      
        tmp = 0;
        for (j = 0; j <= i; ++j) tmp += a[i][j]*k[j][l];
        
        state_[l] = state[l] + h*tmp;
      }
     
      Derivative()(t + c[i]*h, state_, k[i+1]);
    }

    for (l = 0; l < dim; ++l) {
      tmp = 0;
      for (i = 0; i < 13; i++) tmp += b[i]*k[i][l];      
      state[l] += h*tmp; 
    }  
  }
};

template <class T, class F, class Derivative>
int Hairer8 <T,F,Derivative>::order = 8;

/*
  Hairer (p=10) --- world record explicit Runge-Kutta
*/ 
template <class T, class F, class Derivative>
class Hairer10 {

  int dim;
  
  T **a, *b, *c;

  public:
  
  F **k, *state_;

  static int order;
    
  Hairer10 (int dim) : dim(dim) {
    int i, j;
    
    k = new F* [17];    
    for (i = 0; i < 17; ++i) k[i] = new F [dim];
    
    state_ = new F [dim];
    
    c = new T [16]; memset(c,0, sizeof(T)*16);
    
    a = new T* [16];

    for (i = 0; i < 16; ++i) {
      a[i] = new T [i+1];
      for (j = 0; j <= i; ++j) a[i][j] = 0.0;
    }
 
    a[ 0][ 0] =  5.00000000000000000000e-1;
    a[ 1][ 0] =  2.49297267609681978013e-1;
    a[ 1][ 1] =  2.77211832531930184738e-1;
    a[ 2][ 0] =  1.97440912553104561032e-1;
    a[ 2][ 2] =  5.92322737659313683095e-1;
    a[ 3][ 0] =  1.97320548628702140900e-1;
    a[ 3][ 2] =  2.95083334092671853711e-1;
    a[ 3][ 3] = -9.84803125957023833277e-2;
    a[ 4][ 0] =  1.31313417344461520076e-1;
    a[ 4][ 3] =  1.10154439538638507040e-1;
    a[ 4][ 4] =  5.25186129370448772884e-1;
    a[ 5][ 0] =  1.34200341846322406193e-1;
    a[ 5][ 3] =  6.96088703288076908079e-1;
    a[ 5][ 4] =  2.50497721570339375352e-1;
    a[ 5][ 5] = -7.91023116492320445498e-1;
    a[ 6][ 0] =  7.22182741896621454448e-2;
    a[ 6][ 4] = -5.83363229364550369126e-2;
    a[ 6][ 5] =  3.04755766857449437925e-3;
    a[ 6][ 6] =  9.15481802977846100286e-2;
    a[ 7][ 0] =  3.12550081351656170620e-2;
    a[ 7][ 5] =  1.09123821542419946873e-4;
    a[ 7][ 6] =  1.56725758630995015164e-1;
    a[ 7][ 7] =  1.69294351171974399670e-1;
    a[ 8][ 0] =  1.19066044146750321445e-2;
    a[ 8][ 5] =  2.83437082024606548112e-1;
    a[ 8][ 6] = -4.16312167570561315056e-1;
    a[ 8][ 7] =  2.64646333949743004837e-1;
    a[ 8][ 8] =  7.38849809146269076388e-1;
    a[ 9][ 0] =  2.34065736913354493717e-2;
    a[ 9][ 5] =  9.44931301894961802240e-2;
    a[ 9][ 6] = -2.72872055901956419006e-1;
    a[ 9][ 7] =  2.24022046115592207410e-1;
    a[ 9][ 8] =  6.04381441075135095416e-1;
    a[ 9][ 9] = -3.08153769292799652586e-2;
    a[10][ 0] =  4.54437753101763699408e-2;
    a[10][ 5] = -1.18799667186441567723e-3;
    a[10][ 6] =  1.20356549909281134803e-2;
    a[10][ 7] =  7.51269029876479240591e-2;
    a[10][ 8] = -1.82209240988845690412e-2;
    a[10][ 9] = -2.57152854084065042855e-4;
    a[10][10] =  4.53207837134829585506e-3;
    a[11][ 0] =  1.78401086400436429292e-1;
    a[11][ 3] =  1.10154439538638507040e-1;
    a[11][ 4] =  5.25186129370448772884e-1;
    a[11][ 5] = -4.89148591820436212803e-1;
    a[11][ 6] =  9.32443612635135733038e-1;
    a[11][ 7] = -7.74475053439839525409e-1;
    a[11][ 8] = -1.05490217813935824270e+0;
    a[11][ 9] =  1.31046712034157154509e-1;
    a[11][10] =  5.87049777599487392267e-1;
    a[11][11] =  6.20898052074878791881e-1;
    a[12][ 0] =  1.30220806600497793496e-1;
    a[12][ 3] =  6.96088703288076908079e-1;
    a[12][ 4] =  2.50497721570339375352e-1;
    a[12][ 5] = -7.58948987129607342662e-1;
    a[12][ 6] = -1.71517208463488383577e-1;
    a[12][ 7] = -3.70217673678906704688e-1;
    a[12][ 8] =  1.24981008574747347802e-1;
    a[12][ 9] =  3.35310924837267073965e-3;
    a[12][10] = -6.63254613676153581907e-3;
    a[12][11] =  4.29116573121617904714e-1;
    a[12][12] = -3.71778567824697893108e-2;
    a[13][ 0] =  2.49297267609681978013e-1;
    a[13][ 1] =  2.77211832531930184738e-1;
    a[13][ 5] = -1.45940595936085218185e-1;
    a[13][ 6] = -7.99015893511029475358e-1;
    a[13][12] =  1.45940595936085218185e-1;
    a[13][13] =  7.99015893511029475358e-1;
    a[14][ 0] =  5.00000000000000000000e-1;
    a[14][ 2] = -8.07097076095341093251e-1;
    a[14][14] =  8.07097076095341093251e-1;
    a[15][ 0] =  5.73207954320575412321e-2;
    a[15][ 1] = -5.00000000000000000000e-1;
    a[15][ 2] = -8.97470163394855120846e-1;
    a[15][ 5] = -1.03991004922695343354e+0;
    a[15][ 6] = -4.07357014288385809022e-1;
    a[15][ 7] = -1.82830236640741849663e-1;
    a[15][ 8] = -3.33659270649225021137e-1;
    a[15][ 9] =  3.95648542376057924001e-1;
    a[15][10] =  6.95057049459982281780e-1;
    a[15][11] =  2.71487376457383239111e-1;
    a[15][12] =  5.85423734866589756811e-1;
    a[15][13] =  9.58819072213235370429e-1;
    a[15][14] =  8.97470163394855184206e-1;
    a[15][15] =  5.00000000000000000000e-1;

    b = new T [17]; memset(b,0, sizeof(T)*17);
    b[ 0] =  3.33333333333333333333e-2;
    b[ 1] = -3.33333333333333333333e-2;
    b[ 2] = -1.20000000000000000000e-1;
    b[ 5] = -1.30000000000000000000e-1;
    b[ 6] = -1.80000000000000000000e-1;
    b[ 8] =  2.77429188517743176508e-1;
    b[ 9] =  1.89237478148923490158e-1;
    b[10] =  2.77429188517743176508e-1;
    b[11] =  1.89237478148923490158e-1;
    b[12] =  1.30000000000000000000e-1;
    b[13] =  1.80000000000000000000e-1;
    b[14] =  1.20000000000000000000e-1;
    b[15] =  3.33333333333333333333e-2;
    b[16] =  3.33333333333333333333e-2;
    
    c = new T [16];
    c[ 0] =  5.00000000000000000000e-1;
    c[ 1] =  5.26509100141612162751e-1;
    c[ 2] =  7.89763650212418244126e-1;
    c[ 3] =  3.93923570125671611283e-1;
    c[ 4] =  7.66653986253548800000e-1;
    c[ 5] =  2.89763650212418244126e-1;
    c[ 6] =  1.08477689219566212940e-1;
    c[ 7] =  3.57384241759677451843e-1;
    c[ 8] =  8.82527661964732346426e-1;
    c[ 9] =  6.42615758240322548157e-1;
    c[10] =  1.17472338035267653574e-1;
    c[11] =  7.66653986253548800000e-1;
    c[12] =  2.89763650212418244126e-1;
    c[13] =  5.26509100141612162751e-1;
    c[14] =  5.00000000000000000000e-1;
    c[15] =  1.00000000000000000000e+0;
  
  }
  
  ~Hairer10(){

    int i;
   
    delete [] b;
    delete [] c;
    
    for (i = 0; i < 16; i++) delete [] a[i];
    delete [] a;

    delete [] state_;    
    
    for (i = 0; i < 17; i++) delete [] k[i];
    delete [] k;

  }
  
  void step(const T &h, const T &t, F *state, F* k0 = 0){

    int i, j, l;
    
    F tmp;
    
    if (k0 == 0) 
      Derivative()(t, state, k[0]);
    else if (k0 != k[0])
      memcpy(k[0], k0 , sizeof(F)*dim);
      
    for (i = 0; i < 16; ++i) {
      
      for (l = 0; l < dim; ++l) {
      
        tmp = 0;
        for (j = 0; j <= i; ++j) tmp += a[i][j]*k[j][l];
        
        state_[l] = state[l] + h*tmp;
      }
     
      Derivative()(t + c[i]*h, state_, k[i+1]);
    }
    
    for (l = 0; l < dim; ++l) {
      tmp = 0;
      for (i = 0; i < 17; i++) tmp += b[i]*k[i][l];      
      state[l] += h*tmp; 
    }  
  }
};

template <class T, class F, class Derivative>
int Hairer10 <T,F,Derivative>::order = 10;


#endif

